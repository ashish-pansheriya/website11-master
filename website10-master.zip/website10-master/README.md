# website6 L2 base python

<h3>A Classified ads posting and the Social gethering website by using the Django mainframe</h3>
Install dependencies by running $pip install -r requirements.txt 
 or Install packages using $pip install 'package' command 


create & migrate database/tables

      pip install -r requirements.txt
      python manage.py makemigrations
      python manage.py migrate
      python manage.py runserver 
 
 
 __local host__
 http://127.0.0.1:8000/



